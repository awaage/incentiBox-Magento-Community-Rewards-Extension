<?php
class IncentiBox_Communityrewards_Model_Listener extends Mage_Core_Model_Abstract
{
	function _construct(){
		$this->_init('communityrewards/listener');
	}
}
?>